"""PyStudio runtime.

    from studio import images, show

images()       -> image files in the working folder
show(x, name)  -> send an RGB image / NumPy array / file path to the console
cv2.imshow()   -> works too; every call becomes its own output in the console
"""
import builtins
import json
import linecache
import os
import queue
import re
import sys
import threading
import time
import traceback

import pm

try:
    import ctypes

    _setasync = ctypes.pythonapi.PyThreadState_SetAsyncExc
    _setasync.argtypes = (ctypes.c_ulong, ctypes.py_object)
except Exception:  # pragma: no cover
    ctypes = None
    _setasync = None

_OUT = ""
_n = 0
_em = None
_tid = 0
_stop = False
_inq = queue.Queue()
_STOP = object()
_real_sleep = time.sleep
_EXT = (".png", ".jpg", ".jpeg", ".jfif", ".webp", ".bmp", ".gif", ".tif", ".tiff")


def setup(out_dir, site_dir):
    global _OUT
    _OUT = out_dir
    os.makedirs(_OUT, exist_ok=True)
    pm.setup(site_dir)


# ----------------------------------------------------------------- output
class _Emitter:
    """Batches console text (max ~20 msgs/s) and keeps text/image order."""

    def __init__(self, sink):
        self.sink = sink
        self.items = []
        self.last = 0.0
        self.timer = None
        self.lock = threading.RLock()

    def emit(self, kind, text):
        if not text:
            return
        with self.lock:
            self.items.append([kind, text])
            if time.time() - self.last > 0.05:
                self._flush()
            elif self.timer is None:
                self.timer = threading.Timer(0.06, self.flush)
                self.timer.daemon = True
                self.timer.start()

    def flush(self):
        with self.lock:
            self._flush()

    def _flush(self):
        self.timer = None
        items, self.items = self.items, []
        self.last = time.time()
        merged = []
        for k, t in items:
            if merged and merged[-1][0] == k:
                merged[-1][1] += t
            else:
                merged.append([k, t])
        for k, t in merged:
            self.sink.accept(k + ":" + t)

    def direct(self, kind, text):
        with self.lock:
            self._flush()
            self.sink.accept(kind + ":" + text)


class _W:
    encoding = "utf-8"

    def __init__(self, em, kind):
        self.em, self.kind = em, kind

    def write(self, s):
        self.em.emit(self.kind, s)
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False


# ----------------------------------------------------------------- helpers for user code
def images():
    try:
        names = os.listdir(os.getcwd())
    except OSError:
        return []
    return sorted(os.path.join(os.getcwd(), f) for f in names if f.lower().endswith(_EXT))


def show(obj, title=None):
    global _n
    from PIL import Image

    if isinstance(obj, str):
        obj = Image.open(obj)
    elif not isinstance(obj, Image.Image):
        import numpy as np

        a = np.asarray(obj)
        if a.dtype != np.uint8:
            a = np.clip(a, 0, 255).astype(np.uint8)
        if a.ndim == 3 and a.shape[2] == 1:
            a = a[:, :, 0]
        obj = Image.fromarray(a)
    name = re.sub(r"[^\w\-]+", "_", str(title if title else "image")).strip("_")[:40] or "image"
    _n += 1
    path = os.path.join(_OUT, "%02d_%s.png" % (_n, name))
    obj.save(path)
    if _em is not None:
        _em.direct("i", path)
    return path


def _patch_cv2():
    """opencv-python-headless has no windows: route imshow to the console."""
    try:
        import cv2
        import numpy as np
    except Exception:
        return

    def imshow(title, img):
        a = np.asarray(img)
        if a.dtype.kind == "f":
            a = a * 255.0
        elif a.dtype == np.uint16:
            a = a // 256
        if a.ndim == 3 and a.shape[2] in (3, 4):
            a = np.clip(a, 0, 255).astype(np.uint8)
            a = cv2.cvtColor(a, cv2.COLOR_BGR2RGB if a.shape[2] == 3 else cv2.COLOR_BGRA2RGBA)
        show(a, title)

    def _noop(*args, **kwargs):
        return None

    cv2.imshow = imshow
    cv2.waitKey = lambda *args, **kwargs: -1
    cv2.waitKeyEx = cv2.waitKey
    for n in ("destroyAllWindows", "destroyWindow", "namedWindow",
              "moveWindow", "resizeWindow", "setWindowTitle"):
        setattr(cv2, n, _noop)


def _input(prompt=""):
    _em.emit("o", str(prompt))
    _em.direct("q", str(prompt))
    v = _inq.get()
    if v is _STOP:
        raise KeyboardInterrupt
    _em.emit("o", v + "\n")
    return v


def _sleep(s):
    end = time.time() + s
    while True:
        if _stop:
            raise KeyboardInterrupt
        left = end - time.time()
        if left <= 0:
            return
        _real_sleep(min(left, 0.1))


def _tracer(frame, event, arg):
    if _stop:
        raise KeyboardInterrupt
    return None


# ----------------------------------------------------------------- control
def info():
    import platform

    parts = ["Python " + platform.python_version()]
    for mod, label in (("numpy", "NumPy"), ("PIL", "Pillow"), ("cv2", "OpenCV")):
        try:
            m = __import__(mod)
            parts.append((label + " " + str(getattr(m, "__version__", ""))).strip())
        except Exception:
            pass
    return "  \u00b7  ".join(parts)


def provide_input(text):
    _inq.put(text)


def stop():
    global _stop
    _stop = True
    _inq.put(_STOP)
    if _setasync is not None and _tid:
        try:
            _setasync(ctypes.c_ulong(_tid), ctypes.py_object(KeyboardInterrupt))
        except Exception:
            pass


def run(code, cwd, name, sink):
    global _em, _n, _tid, _stop
    _em = _Emitter(sink)
    _n = 0
    _stop = False
    _tid = threading.get_ident()
    while not _inq.empty():
        _inq.get_nowait()
    for f in os.listdir(_OUT):
        try:
            os.remove(os.path.join(_OUT, f))
        except OSError:
            pass
    if cwd and os.path.isdir(cwd):
        os.chdir(cwd)
        if cwd not in sys.path:
            sys.path.insert(0, cwd)
    for mn, m in list(sys.modules.items()):  # fresh imports of the user's own modules
        f = getattr(m, "__file__", None)
        if f and ((cwd and f.startswith(cwd + os.sep)) or f.startswith(pm.SITE + os.sep)):
            sys.modules.pop(mn, None)
    _patch_cv2()

    fname = name or "main.py"
    linecache.cache[fname] = (len(code), None, code.splitlines(True), fname)
    g = {"__name__": "__main__", "__file__": os.path.join(cwd or "", fname)}
    sys.argv = [fname]
    saved = (sys.stdout, sys.stderr, builtins.input, time.sleep)
    sys.stdout, sys.stderr = _W(_em, "o"), _W(_em, "e")
    builtins.input, time.sleep = _input, _sleep
    if _setasync is None:
        sys.settrace(_tracer)
    ok = True
    try:
        pm.auto_install(code, lambda line: _em.emit("o", line + "\n"))
        exec(compile(code, fname, "exec"), g)
    except SystemExit:
        pass
    except KeyboardInterrupt:
        ok = False
        _em.emit("e", "\nStopped.\n")
    except BaseException:
        ok = False
        et, ev, tb = sys.exc_info()
        _em.emit("e", "".join(traceback.format_exception(et, ev, tb.tb_next)))
    finally:
        sys.settrace(None)
        _tid = 0
        sys.stdout, sys.stderr, builtins.input, time.sleep = saved
        _em.flush()
    return json.dumps({"ok": ok})
