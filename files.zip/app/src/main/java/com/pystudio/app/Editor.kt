package com.pystudio.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------ syntax highlighting
class PyHighlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        fun paint(r: Regex, c: Color) {
            r.findAll(s).forEach { b.addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1) }
        }
        paint(NUM, Amber)
        paint(KW, Pink)
        paint(FN, Cyan)
        paint(SELF, SelfColor)
        paint(DEC, Amber)
        paint(STR, Mint)
        paint(COM, Dim)
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }

    private companion object {
        val SelfColor = Color(0xFFB69CFF)
        val NUM = Regex("""\b\d+(\.\d+)?\b""")
        val KW = Regex("""\b(def|class|import|from|as|return|if|elif|else|for|while|in|not|and|or|is|try|except|finally|with|lambda|pass|break|continue|None|True|False|raise|yield|global|nonlocal|del|assert|async|await)\b""")
        val FN = Regex("""\b(print|len|range|open|int|str|float|bool|list|dict|set|tuple|enumerate|zip|map|filter|sum|min|max|abs|sorted|reversed|isinstance|input|round|type|any|all)\b|(?<=def\s)\w+|(?<=class\s)\w+""")
        val SELF = Regex("""\b(self|cls)\b""")
        val DEC = Regex("""(?m)^[ \t]*@[\w.]+""")
        val STR = Regex("""("{3}[\s\S]*?"{3}|'{3}[\s\S]*?'{3}|"[^"\n]*"|'[^'\n]*')""")
        val COM = Regex("""#[^\n]*""")
    }
}

// ------------------------------------------------------------ undo / redo
class UndoStack {
    private val past = ArrayList<TextFieldValue>()
    private val future = ArrayList<TextFieldValue>()
    private var lastAt = 0L

    fun record(old: TextFieldValue, new: TextFieldValue) {
        if (old.text == new.text) return
        val now = System.currentTimeMillis()
        if (past.isEmpty() || now - lastAt > 800 || kotlin.math.abs(new.text.length - old.text.length) > 1) {
            past.add(old)
            if (past.size > 300) past.removeAt(0)
        }
        lastAt = now
        future.clear()
    }

    fun undo(cur: TextFieldValue): TextFieldValue? {
        if (past.isEmpty()) return null
        future.add(cur)
        return past.removeAt(past.size - 1)
    }

    fun redo(cur: TextFieldValue): TextFieldValue? {
        if (future.isEmpty()) return null
        past.add(cur)
        return future.removeAt(future.size - 1)
    }

    fun clear() {
        past.clear()
        future.clear()
    }
}

// ------------------------------------------------------------ smart typing
private val PAIRS = mapOf('(' to ')', '[' to ']', '{' to '}', '"' to '"', '\'' to '\'')

fun insertText(v: TextFieldValue, s: String): TextFieldValue {
    val a = v.selection.min
    val b = v.selection.max
    return TextFieldValue(v.text.replaceRange(a, b, s), TextRange(a + s.length))
}

/** Auto-indent, auto-closing brackets/quotes, step-over closers, pair-delete. */
fun smartEdit(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
    val o = old.text
    val n = new.text
    if (!old.selection.collapsed || !new.selection.collapsed) return new
    val c = new.selection.start

    if (n.length == o.length + 1 && c in 1..n.length && n.removeRange(c - 1, c) == o) {
        val ch = n[c - 1]
        val next = if (c < n.length) n[c] else ' '
        val prev = if (c >= 2) n[c - 2] else ' '
        when {
            ch == '\n' -> {
                val lineStart = n.lastIndexOf('\n', c - 2) + 1
                val line = n.substring(lineStart, c - 1)
                var indent = line.takeWhile { it == ' ' || it == '\t' }
                if (line.trimEnd().endsWith(":")) indent += "    "
                if (indent.isNotEmpty()) {
                    return TextFieldValue(n.substring(0, c) + indent + n.substring(c), TextRange(c + indent.length))
                }
            }
            ch == ')' || ch == ']' || ch == '}' -> {
                if (next == ch) return TextFieldValue(o, TextRange(c))
            }
            ch == '"' || ch == '\'' -> {
                if (next == ch) return TextFieldValue(o, TextRange(c))
                if (!prev.isLetterOrDigit() && prev != ch && !next.isLetterOrDigit()) {
                    return TextFieldValue(n.substring(0, c) + ch + n.substring(c), TextRange(c))
                }
            }
            ch == '(' || ch == '[' || ch == '{' -> {
                if (!next.isLetterOrDigit()) {
                    return TextFieldValue(n.substring(0, c) + PAIRS[ch] + n.substring(c), TextRange(c))
                }
            }
        }
        return new
    }

    if (n.length == o.length - 1 && c in 0 until n.length && o.removeRange(c, c + 1) == n && PAIRS[o[c]] == n[c]) {
        return TextFieldValue(n.removeRange(c, c + 1), TextRange(c))
    }
    return new
}

// ------------------------------------------------------------ editor view
@Composable
fun CodeEditor(
    value: TextFieldValue,
    fontSp: Float,
    onChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier
) {
    val highlight = remember { PyHighlight() }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val lines = remember(value.text) { value.text.count { it == '\n' } + 1 }
    val numbers = remember(lines) { (1..lines).joinToString("\n") }
    val digits = maxOf(2, lines.toString().length)
    val gutter = (digits * fontSp * 0.62f + 24f).dp
    val style = TextStyle(
        color = Ink, fontFamily = FontFamily.Monospace,
        fontSize = fontSp.sp, lineHeight = (fontSp * 1.55f).sp
    )

    BoxWithConstraints(modifier) {
        val screenH = maxHeight
        val minW = maxWidth - gutter
        Row(Modifier.fillMaxWidth().heightIn(min = screenH).verticalScroll(vScroll)) {
            Text(
                numbers,
                style = style.copy(color = Dim.copy(alpha = 0.55f), textAlign = TextAlign.End),
                modifier = Modifier.width(gutter).padding(top = 14.dp, end = 12.dp)
            )
            Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    textStyle = style,
                    cursorBrush = SolidColor(Cyan),
                    visualTransformation = highlight,
                    modifier = Modifier.widthIn(min = minW).heightIn(min = screenH)
                        .padding(start = 4.dp, top = 14.dp, end = 24.dp, bottom = 120.dp)
                )
            }
        }
    }
}

// ------------------------------------------------------------ symbol row above the keyboard
@Composable
private fun Key(label: String, accent: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 3.dp).clip(RoundedCornerShape(10.dp))
            .background(if (accent) Violet.copy(alpha = 0.30f) else Card2)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 16.sp) }
}

@Composable
fun KeysBar(
    onKey: (String) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit
) {
    val symbols = listOf(
        "(", ")", "[", "]", "{", "}", "\"", "'", ":", "=", "#", "_", ".", ",",
        "+", "-", "*", "/", "%", "<", ">", "\\", "!", "&", "|", ";", "@"
    )
    Column(Modifier.fillMaxWidth().background(Card)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 6.dp)) {
            Key("\u21E5", true) { onKey("    ") }
            Key("\u21B6", true, onUndo)
            Key("\u21B7", true, onRedo)
            Key("\u25C0", true, onLeft)
            Key("\u25B6", true, onRight)
            symbols.forEach { s -> Key(s) { onKey(s) } }
        }
    }
}
