package com.pystudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.exifinterface.media.ExifInterface
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.function.Consumer
import kotlin.concurrent.thread

// ---------- palette ----------
val Bg = Color(0xFF060A13)
val Card = Color(0xFF0E1525)
val Card2 = Color(0xFF151F36)
val Line = Color(0xFF212D4A)
val Ink = Color(0xFFE8EDFF)
val Dim = Color(0xFF8692B3)
val Cyan = Color(0xFF22D3EE)
val Violet = Color(0xFF8B5CF6)
val Pink = Color(0xFFF472B6)
val Mint = Color(0xFF34D399)
val Amber = Color(0xFFFBBF24)
val Rose = Color(0xFFFB7185)
val Grad = Brush.linearGradient(listOf(Cyan, Violet))
val GradStop = Brush.linearGradient(listOf(Rose, Color(0xFFF97316)))

// ---------- python bridge ----------
object Py {
    private val main = Handler(Looper.getMainLooper())
    private fun studio() = Python.getInstance().getModule("studio")
    private fun pm() = Python.getInstance().getModule("pm")

    fun start(ctx: Context): String {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx.applicationContext))
        studio().callAttr(
            "setup",
            File(ctx.filesDir, "outputs").apply { mkdirs() }.absolutePath,
            File(ctx.filesDir, "site-packages").apply { mkdirs() }.absolutePath
        )
        return studio().callAttr("info").toString()
    }

    /** Runs code on its own big-stack thread. Messages: "o:" stdout, "e:" stderr, "i:" image path, "q:" input(). */
    fun run(code: String, cwd: String, name: String, onMsg: (String) -> Unit, onDone: (Boolean) -> Unit) {
        val sink = Consumer<String> { s -> main.post { onMsg(s) } }
        Thread(null, {
            val ok = try {
                JSONObject(studio().callAttr("run", code, cwd, name, sink).toString()).getBoolean("ok")
            } catch (e: Throwable) {
                main.post { onMsg("e:" + (e.message ?: "Python error") + "\n") }
                false
            }
            main.post { onDone(ok) }
        }, "py-run", 16L * 1024 * 1024).start()
    }

    fun terminal(command: String, cwd: String, onResult: (String) -> Unit) {
        thread {
            val result = runCatching { studio().callAttr("terminal", command, cwd).toString() }
                .getOrElse { "Python terminal error: ${it.message ?: it.javaClass.simpleName}" }
            main.post { onResult(result) }
        }
    }

    fun stop() {
        thread { runCatching { studio().callAttr("stop") } }
    }

    fun input(text: String) {
        thread { runCatching { studio().callAttr("provide_input", text) } }
    }

    fun install(name: String, onLog: (String) -> Unit, onDone: (Boolean, String) -> Unit) {
        val sink = Consumer<String> { line -> main.post { onLog(line) } }
        thread {
            val result = runCatching { pm().callAttr("install", name, sink).toString() }
                .getOrElse { "{\"ok\":false,\"error\":\"${it.message ?: "Install failed"}\"}" }
            val ok = runCatching { JSONObject(result).optBoolean("ok", false) }.getOrDefault(false)
            val message = if (ok) "Installation finished." else "Installation failed: " + runCatching { JSONObject(result).optString("error") }.getOrDefault(result)
            main.post { onDone(ok, message) }
        }
    }

    fun uninstallForTerminal(name: String, onDone: (String) -> Unit) {
        thread {
            val result = runCatching { pm().callAttr("uninstall", name, Consumer<String> { }) .toString() }
                .getOrDefault("{\"ok\":false}")
            val ok = runCatching { JSONObject(result).optBoolean("ok", false) }.getOrDefault(false)
            main.post { onDone(if (ok) "Removed $name" else "$name is not installed") }
        }
    }

    fun uninstall(name: String, onDone: () -> Unit) {
        val sink = Consumer<String> { }
        thread {
            runCatching { pm().callAttr("uninstall", name, sink) }
            main.post { onDone() }
        }
    }

    fun listInstalled(onResult: (List<Pair<String, String>>) -> Unit) {
        thread {
            val l = runCatching {
                val a = JSONArray(pm().callAttr("installed").toString())
                (0 until a.length()).map { a.getJSONArray(it).getString(0) to a.getJSONArray(it).getString(1) }
            }.getOrDefault(emptyList())
            main.post { onResult(l) }
        }
    }
}

// ---------- files & permission ----------
fun hasAllFiles(): Boolean = Environment.isExternalStorageManager()

fun openAllFilesSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
        )
    } catch (e: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

/** Where scripts live: /sdcard/PyStudio when file access is granted, otherwise private storage. */
fun scriptsDir(ctx: Context): File =
    (if (hasAllFiles()) File(Environment.getExternalStorageDirectory(), "PyStudio")
    else File(ctx.filesDir, "scripts")).apply { mkdirs() }

fun listDir(d: File): List<File> =
    (d.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList())
        .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))

private val IMG_EXT = setOf("jpg", "jpeg", "jfif", "png", "webp", "bmp", "gif", "tif", "tiff")
private val TEXT_EXT = setOf("py", "txt", "md", "json", "csv", "xml", "html", "js", "yml", "yaml", "cfg", "ini", "log", "toml")
fun isImage(f: File) = f.isFile && f.extension.lowercase() in IMG_EXT
fun isTextFile(f: File) = f.isFile && (f.extension.lowercase() in TEXT_EXT || f.extension.isEmpty())

fun fmtSize(b: Long): String = when {
    b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
    b >= 1024 -> (b / 1024).toString() + " KB"
    else -> "$b B"
}

fun prettyPath(d: File): String =
    "Phone" + d.absolutePath.removePrefix(Environment.getExternalStorageDirectory().absolutePath)

fun saveToGallery(ctx: Context, f: File): Boolean = runCatching {
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PyStudio_" + System.currentTimeMillis() + ".png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PyStudio")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
}.isSuccess

/** Down-sampled decode that also respects the photo's EXIF rotation. */
fun decode(path: String, target: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        ?: return null
    val orientation = runCatching {
        ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
    }.getOrDefault(1)
    val deg = when (orientation) {
        6 -> 90f
        3 -> 180f
        8 -> 270f
        else -> 0f
    }
    if (deg == 0f) return bmp
    val m = Matrix().apply { postRotate(deg) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

@Composable
fun AsyncImg(path: String, target: Int, modifier: Modifier, scale: ContentScale, key: Any = path) {
    val bmp by produceState<ImageBitmap?>(null, path, key) {
        value = withContext(Dispatchers.IO) { decode(path, target)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = scale)
    else Box(modifier.defaultMinSize(minHeight = 120.dp).background(Card2))
}
