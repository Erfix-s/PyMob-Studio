# -*- coding: utf-8 -*-
"""
PyMob Studio — هستهٔ پایتون
اجرا امنِ کد کاربر، خواندن مستقیم تصویر از حافظهٔ گوشی،
نمایش خروجی تصویری و نصب کتابخانه با pip داخلی Chaquopy.
"""

import contextlib
import importlib
import traceback

_bridge = None
_image_uri = None


def init():
    global _bridge, _image_uri
    _bridge = None
    _image_uri = None


def set_image_uri(uri):
    global _image_uri
    _image_uri = uri


def _out(text):
    if _bridge is not None:
        try:
            _bridge.onOutput(str(text))
        except Exception:
            pass


class _Writer(object):
    def write(self, s):
        if s:
            _out(s)

    def flush(self):
        pass


def _read_uri(uri):
    data = _bridge.readUriBytes(uri)
    if data is None:
        raise IOError("خواندن فایل ممکن نشد: %s" % uri)
    return bytes(data)


def imread(path=None):
    """
    خواندن تصویر — بدون کپی، مستقیم از فایل‌های گوشی.
    بدون آرگومان: آخرین تصویر انتخاب‌شده با دکمهٔ 🖼
    یا مسیر واقعی مثل /storage/emulated/0/DCIM/photo.jpg
    خروجی: آرایهٔ NumPy به فرمت BGR (مثل cv2.imread)
    """
    import numpy as np
    import cv2

    if path is None:
        path = _image_uri
    if path is None:
        raise ValueError("هیچ تصویری انتخاب نشده؛ اول دکمهٔ 🖼 را بزنید یا مسیر بدهید.")

    if isinstance(path, str) and path.startswith("content:"):
        data = _read_uri(path)
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    else:
        img = cv2.imread(str(path), cv2.IMREAD_COLOR)

    if img is None:
        raise IOError("تصویر باز نشد: %s" % path)
    return img


def show_image(img, caption=""):
    """نمایش خروجی پردازش‌شده در پنل «تصویر» اپ."""
    import numpy as np
    import cv2

    if img is None:
        raise ValueError("show_image: تصویر خالی است")
    if img.dtype != np.uint8:
        img = np.clip(img, 0, 255).astype(np.uint8)

    ok, buf = cv2.imencode(".png", img)
    if not ok:
        raise IOError("انکود تصویر ناموفق بود")
    _bridge.onImage(bytes(buf.tobytes()))
    if caption:
        _out(caption)


def save_image(img, path):
    import cv2

    ok, buf = cv2.imencode(".png", img)
    if not ok:
        raise IOError("انکود تصویر ناموفق بود")
    data = bytes(buf.tobytes())

    if str(path).startswith("content:"):
        if not _bridge.writeUriBytes(str(path), data):
            raise IOError("نوشتن در فایل ناموفق بود")
    else:
        with open(str(path), "wb") as f:
            f.write(data)
    _out("✓ تصویر ذخیره شد: %s" % path)


def install_package(name, bridge=None):
    global _bridge
    if bridge is not None:
        _bridge = bridge

    name = str(name).strip()
    _out("⏳ در حال نصب «%s» …" % name)
    try:
        import pip
        pip.install(name)
        importlib.invalidate_caches()
        _out("✓ «%s» نصب شد." % name)
        _out("نکته: پکیج‌های بومی (مثل scipy) را بعد از نصب، یک‌بار اپ را بازآغاز کنید.")
        return True
    except Exception as e:
        _out("✗ نصب ناموفق: %s" % e)
        _out("فهرست پکیج‌های پشتیبانی‌شده: https://chaquo.com/pypi-13.1/")
        return False


def run_code(code, bridge=None):
    global _bridge
    if bridge is not None:
        _bridge = bridge

    gl = {"__name__": "__main__", "__file__": "main.py"}

    try:
        import numpy as np
        gl["np"] = np
        gl["numpy"] = np
    except ImportError:
        pass
    try:
        import cv2
        gl["cv2"] = cv2
    except ImportError:
        pass
    try:
        from PIL import Image
        gl["Image"] = Image
        gl["PIL"] = __import__("PIL")
    except ImportError:
        pass

    gl["imread"] = imread
    gl["show_image"] = show_image
    gl["save_image"] = save_image
    gl["install"] = install_package

    err_w = _Writer()
    out_w = _Writer()
    try:
        with contextlib.redirect_stdout(out_w), contextlib.redirect_stderr(err_w):
            exec(compile(str(code), "main.py", "exec"), gl)
        _out("\n— پردازش کامل شد ✓ —")
    except SystemExit:
        _out("\n— اجرا پایان یافت —")
    except Exception:
        _out("\n✗ خطا:\n" + traceback.format_exc())
    finally:
        import gc
        gc.collect()