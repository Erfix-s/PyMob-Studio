package com.pystudio.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class StudioTab { EDITOR, OUTPUT, TERMINAL }

private data class TerminalLine(val command: String, val output: String, val error: Boolean = false)

@Composable
fun TerminalPanel(
    initialDirectory: String,
    onPipInstall: (String, (String) -> Unit, (String) -> Unit) -> Unit,
    onPipUninstall: (String, (String) -> Unit) -> Unit,
    onPipList: ((String) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var cwd by remember { mutableStateOf(File(initialDirectory).takeIf { it.isDirectory } ?: File("/sdcard")) }
    var input by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf<TerminalLine>() }
    var busy by remember { mutableStateOf(false) }

    fun emit(s: String, error: Boolean = false) {
        lines.add(TerminalLine("", s, error))
        if (lines.size > 500) lines.removeAt(0)
    }

    fun execute(raw: String) {
        val command = raw.trim()
        if (command.isEmpty() || busy) return
        lines.add(TerminalLine("${cwd.absolutePath} \$ $command", ""))
        input = ""
        when {
            command == "clear" -> lines.clear()
            command == "help" -> emit("Android shell commands: pwd, ls, cd, mkdir, touch, cat, cp, mv, rm, echo, whoami, date, df, pip install/list/uninstall.\nThis is the Android shell, not a full Linux distribution: apt/sudo/systemctl are not available.")
            command == "pwd" -> emit(cwd.absolutePath)
            command == "cd" || command.startsWith("cd ") -> {
                val target = command.removePrefix("cd").trim().ifEmpty { "/sdcard" }
                val next = if (target.startsWith("/")) File(target) else File(cwd, target)
                if (next.isDirectory) cwd = next.canonicalFile else emit("cd: no such directory: $target", true)
            }
            command.startsWith("pip install ") -> {
                val pkg = command.removePrefix("pip install ").trim()
                if (pkg.isBlank() || pkg.startsWith("-") || pkg.contains(";")) emit("Usage: pip install package-name", true)
                else {
                    busy = true
                    onPipInstall(pkg, { log -> emit(log) }, { result -> emit(result); busy = false })
                }
            }
            command.startsWith("pip uninstall ") -> {
                val pkg = command.removePrefix("pip uninstall ").trim().removeSuffix(" -y").trim()
                if (pkg.isBlank()) emit("Usage: pip uninstall package-name", true)
                else {
                    busy = true
                    onPipUninstall(pkg) { result -> emit(result); busy = false }
                }
            }
            command == "pip list" -> onPipList { result -> emit(result) }
            command.startsWith("pip ") -> emit("Supported package commands: pip install package, pip uninstall package, pip list. Native-code packages must be bundled into the APK.", true)
            else -> {
                busy = true
                CoroutineScope(Dispatchers.Main).launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            val proc = ProcessBuilder("/system/bin/sh", "-c", command)
                                .directory(cwd)
                                .redirectErrorStream(true)
                                .start()
                            val text = proc.inputStream.bufferedReader().use { it.readText() }
                            val code = proc.waitFor()
                            if (code == 0) text.ifBlank { "(completed)" } else "[exit $code]\n" + text.ifBlank { "Command failed" }
                        }.getOrElse { "${it.javaClass.simpleName}: ${it.message}" }
                    }
                    emit(result, result.startsWith("[exit ") || result.startsWith("Exception:") || result.startsWith("IOException:"))
                    busy = false
                }
            }
        }
    }

    Column(
        Modifier.fillMaxWidth().then(modifier).padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp)).background(Color(0xFF080D18))
            .border(1.dp, Line, RoundedCornerShape(18.dp))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(Mint))
            Spacer(Modifier.width(9.dp))
            Text("TERMINAL", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.weight(1f))
            Text(if (busy) "Running…" else "Android shell", color = Dim, fontSize = 11.sp)
            Text("  Clear", color = Cyan, fontSize = 12.sp, modifier = Modifier.clickable { lines.clear() }.padding(start = 8.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
            SelectionContainer {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                    if (lines.isEmpty()) item {
                        Text("Welcome to PyStudio Terminal\nType help to see available commands.", color = Dim, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 19.sp)
                    }
                    items(lines) { line ->
                        Column {
                            if (line.command.isNotEmpty()) Text(line.command, color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            if (line.output.isNotEmpty()) Text(line.output, color = if (line.error) Rose else Ink, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(12.dp)).background(Card2).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("\$", color = Mint, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(9.dp))
            Box(Modifier.weight(1f)) {
                if (input.isEmpty()) Text("Enter command…", color = Dim, fontSize = 13.sp)
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    singleLine = true,
                    enabled = !busy,
                    textStyle = TextStyle(color = Ink, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    cursorBrush = SolidColor(Cyan),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { execute(input) }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text("Run", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.clickable(enabled = !busy) { execute(input) }.padding(start = 10.dp))
        }
    }
}
