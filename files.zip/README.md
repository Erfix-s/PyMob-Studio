# PyMob Studio 🐍📱

اپ اندروید مدرن اجرای پایتون با OpenCV/NumPy — ادیتور حرفه‌ای، نصب کتابخانه و پردازش تصویر مستقیم از حافظهٔ گوشی.

## بیلد روی گیت‌هاب (۳ قدم)
1. فایل `files.zip` را در ریپازیتوری آپلود (یا جایگزین) کنید.
2. فایل `android.yml` را در مسیر `.github/workflows/android.yml` قرار دهید.
3. تب Actions → بعد از اتمام، APK را از Artifacts دانلود کنید.

## امکانات
- 🎨 رابط تیرهٔ مدرن با ادیتور حرفه‌ای (هایلایت خط فعال، شمارهٔ خط، سینتکس کامل)
- 🖼 انتخاب تصویر از گالری — خواندن مستقیم، بدون کپی
- `imread()` / `show_image(img)` / `save_image(img, path)`
- 📦 نصب پکیج از داخل اپ (numpy و opencv پیش‌نصب‌اند)

## نمونه کد
```python
img  = imread()
gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray, 100, 200)
show_image(edges)
```

فهرست پکیج‌ها: https://chaquo.com/pypi-13.1/ · لایسنس: MIT