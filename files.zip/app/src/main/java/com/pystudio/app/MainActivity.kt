package com.pystudio.app

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicLong

private val STARTER = """
import cv2
import numpy as np

img = np.zeros((260, 520, 3), np.uint8)
img[:] = (255, 120, 40)
cv2.putText(img, "PyStudio", (110, 150), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 4)

cv2.imshow("hello", img)
print("Hello from Python!")
""".trimIndent()

class SaveAsReq(val after: (() -> Unit)?)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, background = Bg, surface = Card, onSurface = Ink
                )
            ) { App(tick) }
        }
    }

    // coming back from the "All files access" settings screen re-checks the permission
    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
fun MenuLine() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val density = LocalDensity.current
    val prefs = remember { ctx.getSharedPreferences("pystudio2", Context.MODE_PRIVATE) }
    val granted = remember(tick) { hasAllFiles() }
    val workspace = remember(granted) { scriptsDir(ctx) }
    val undo = remember { UndoStack() }
    val ids = remember { AtomicLong() }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    // ---------------- document
    val init = remember {
        val f = prefs.getString("file", null)?.let { File(it) }?.takeIf { it.isFile }
        val disk = f?.let { runCatching { it.readText() }.getOrNull() }
        val draft = prefs.getString("draft", null)
        Triple(f, disk ?: (if (draft == null) STARTER else ""), draft ?: disk ?: STARTER)
    }
    var curFile by remember { mutableStateOf(init.first) }
    var savedText by remember { mutableStateOf(init.second) }
    var code by remember { mutableStateOf(TextFieldValue(init.third)) }
    var fontSp by remember { mutableFloatStateOf(prefs.getFloat("font", 14f)) }
    var cwdOverride by remember { mutableStateOf(prefs.getString("cwd", null)) }
    val dirty = code.text != savedText
    val cwd = cwdOverride?.takeIf { File(it).isDirectory } ?: curFile?.parentFile?.absolutePath ?: workspace.absolutePath

    // ---------------- run state
    val feed = remember { mutableStateListOf<Item>() }
    var status by remember { mutableStateOf(Status.IDLE) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var awaiting by remember { mutableStateOf(false) }
    var stopping by remember { mutableStateOf(false) }
    var consoleOpen by remember { mutableStateOf(false) }
    var workspaceTab by remember { mutableStateOf(StudioTab.EDITOR) }
    var consoleH by remember { mutableStateOf(280.dp) }
    var info by remember { mutableStateOf("Starting Python\u2026") }
    var ready by remember { mutableStateOf(false) }

    // ---------------- dialogs
    var menu by remember { mutableStateOf(false) }
    var showOpen by remember { mutableStateOf(false) }
    var showInsert by remember { mutableStateOf(false) }
    var showFolder by remember { mutableStateOf(false) }
    var showLibs by remember { mutableStateOf(false) }
    var saveAs by remember { mutableStateOf<SaveAsReq?>(null) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var viewer by remember { mutableStateOf<Img?>(null) }
    var permAsk by remember { mutableStateOf(true) }

    val imeVisible = WindowInsets.isImeVisible

    LaunchedEffect(Unit) {
        val r = withContext(Dispatchers.IO) { runCatching { Py.start(ctx) } }
        r.onSuccess { info = it; ready = true }
            .onFailure { info = "Python failed to start: " + it.message }
    }
    LaunchedEffect(status) {
        while (status == Status.RUNNING) {
            elapsed = System.currentTimeMillis() - startMs
            delay(100)
        }
    }

    // ---------------- editing
    fun persist() {
        prefs.edit().putString("draft", code.text).putString("file", curFile?.absolutePath).apply()
    }

    fun edit(new: TextFieldValue) {
        val v = smartEdit(code, new)
        undo.record(code, v)
        code = v
        prefs.edit().putString("draft", v.text).apply()
    }

    fun doUndo() {
        val u = undo.undo(code)
        if (u != null) {
            code = u
            persist()
        }
    }

    fun doRedo() {
        val u = undo.redo(code)
        if (u != null) {
            code = u
            persist()
        }
    }

    fun moveCursor(d: Int) {
        val p = (code.selection.start + d).coerceIn(0, code.text.length)
        code = code.copy(selection = TextRange(p))
    }

    // ---------------- files
    fun writeTo(f: File): Boolean {
        val ok = runCatching {
            f.parentFile?.mkdirs()
            f.writeText(code.text)
        }.isSuccess
        if (ok) {
            curFile = f
            savedText = code.text
            persist()
        }
        return ok
    }

    fun save(after: (() -> Unit)? = null) {
        val f = curFile
        if (f == null) {
            saveAs = SaveAsReq(after)
        } else if (writeTo(f)) {
            toast("Saved " + f.name)
            after?.invoke()
        } else {
            toast("Could not save - check file access")
        }
    }

    fun trySaveAs(raw: String, req: SaveAsReq): String? {
        var n = raw.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (n.isEmpty()) return "Enter a file name"
        if (!n.contains('.')) n += ".py"
        val f = File(curFile?.parentFile ?: workspace, n)
        if (f.exists() && f != curFile) return "A file with this name already exists"
        if (!writeTo(f)) return "Could not save here"
        toast("Saved " + f.name)
        saveAs = null
        req.after?.invoke()
        return null
    }

    fun guard(action: () -> Unit) {
        if (dirty) pending = action else action()
    }

    fun openFile(f: File) {
        val t = runCatching { f.readText() }.getOrNull()
        if (t == null) {
            toast("Cannot read this file")
            return
        }
        curFile = f
        savedText = t
        code = TextFieldValue(t)
        undo.clear()
        persist()
    }

    fun newFile() {
        curFile = null
        savedText = ""
        code = TextFieldValue("")
        undo.clear()
        persist()
    }

    // ---------------- running
    fun appendText(s: String, err: Boolean) {
        val last = feed.lastOrNull()
        if (last is Txt && last.err == err) {
            feed[feed.lastIndex] = last.copy(text = (last.text + s).takeLast(200_000))
        } else {
            feed.add(Txt(ids.incrementAndGet(), s, err))
        }
    }

    fun addImage(path: String) {
        val i = feed.indexOfFirst { it is Img && it.path == path }
        if (i >= 0) {
            val old = feed[i] as Img
            feed[i] = old.copy(ver = old.ver + 1)
        } else {
            feed.add(Img(ids.incrementAndGet(), path, 0))
        }
    }

    fun onMsg(m: String) {
        if (m.length < 2) return
        val body = m.substring(2)
        when (m[0]) {
            'o' -> appendText(body, false)
            'e' -> appendText(body, true)
            'i' -> addImage(body)
            'q' -> awaiting = true
        }
    }

    fun run() {
        if (!ready || status == Status.RUNNING) return
        focus.clearFocus()
        feed.clear()
        awaiting = false
        stopping = false
        consoleOpen = true
        workspaceTab = StudioTab.OUTPUT
        status = Status.RUNNING
        startMs = System.currentTimeMillis()
        elapsed = 0L
        Py.run(code.text, cwd, curFile?.name ?: "main.py", { onMsg(it) }) { ok ->
            elapsed = System.currentTimeMillis() - startMs
            awaiting = false
            status = if (stopping) Status.STOPPED else if (ok) Status.OK else Status.ERROR
        }
    }

    fun stop() {
        stopping = true
        Py.stop()
    }

    // ================= UI =================
    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding()) {
        Box(
            Modifier.size(340.dp).offset(x = (-110).dp, y = (-170).dp)
                .background(Brush.radialGradient(listOf(Violet.copy(alpha = 0.28f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomEnd).size(300.dp).offset(x = 120.dp, y = 140.dp)
                .background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.16f), Color.Transparent)), CircleShape)
        )

        Column(Modifier.fillMaxSize()) {
            // ---- top bar
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { showOpen = true }
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            curFile?.name ?: "untitled.py", color = Ink, fontWeight = FontWeight.Bold,
                            fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (dirty) {
                            Spacer(Modifier.width(8.dp))
                            Box(Modifier.size(8.dp).clip(CircleShape).background(Amber))
                        }
                    }
                    Text(
                        if (ready) "\uD83D\uDCC2 " + prettyPath(File(cwd)) else info,
                        color = Dim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                val running = status == Status.RUNNING
                Row(
                    Modifier.alpha(if (ready) 1f else 0.5f).clip(RoundedCornerShape(22.dp))
                        .background(if (running) GradStop else Grad)
                        .clickable(enabled = ready) { if (running) stop() else run() }
                        .padding(horizontal = 18.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (running) Box(Modifier.size(13.dp).clip(RoundedCornerShape(3.dp)).background(Color.White))
                    else Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (running) "Stop" else "Run", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Box {
                    Box(
                        Modifier.clip(CircleShape).clickable { menu = true }.padding(10.dp)
                    ) { Icon(Icons.Filled.MoreVert, null, tint = Ink) }
                    DropdownMenu(
                        expanded = menu,
                        onDismissRequest = { menu = false },
                        modifier = Modifier.background(Card2)
                    ) {
                        DropdownMenuItem(
                            text = { Text("New file", color = Ink) },
                            onClick = { menu = false; guard { newFile() } }
                        )
                        DropdownMenuItem(
                            text = { Text("Open\u2026", color = Ink) },
                            onClick = { menu = false; showOpen = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Save", color = Ink) },
                            onClick = { menu = false; save() }
                        )
                        DropdownMenuItem(
                            text = { Text("Save as\u2026", color = Ink) },
                            onClick = { menu = false; saveAs = SaveAsReq(null) }
                        )
                        MenuLine()
                        DropdownMenuItem(
                            text = { Text("Insert file path\u2026", color = Ink) },
                            onClick = { menu = false; showInsert = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Working folder\u2026", color = Ink) },
                            onClick = { menu = false; showFolder = true }
                        )
                        if (cwdOverride != null) {
                            DropdownMenuItem(
                                text = { Text("Use script's folder", color = Ink) },
                                onClick = {
                                    menu = false
                                    cwdOverride = null
                                    prefs.edit().remove("cwd").apply()
                                }
                            )
                        }
                        MenuLine()
                        DropdownMenuItem(
                            text = { Text("Libraries", color = Ink) },
                            onClick = { menu = false; showLibs = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Text size +", color = Ink) },
                            onClick = {
                                fontSp = (fontSp + 1f).coerceAtMost(24f)
                                prefs.edit().putFloat("font", fontSp).apply()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Text size \u2212", color = Ink) },
                            onClick = {
                                fontSp = (fontSp - 1f).coerceAtLeast(10f)
                                prefs.edit().putFloat("font", fontSp).apply()
                            }
                        )
                        if (!granted) {
                            DropdownMenuItem(
                                text = { Text("Allow file access\u2026", color = Amber) },
                                onClick = { menu = false; openAllFilesSettings(ctx) }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("About", color = Ink) },
                            onClick = { menu = false; toast(info) }
                        )
                    }
                }
            }

            // ---- main workspace: independent editor, output and terminal screens
            when (workspaceTab) {
                StudioTab.EDITOR -> {
                    CodeEditor(
                        value = code,
                        fontSp = fontSp,
                        onChange = { edit(it) },
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(20.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(20.dp))
                    )
                    if (imeVisible && !awaiting) {
                        KeysBar(
                            onKey = { edit(insertText(code, it)) },
                            onUndo = { doUndo() },
                            onRedo = { doRedo() },
                            onLeft = { moveCursor(-1) },
                            onRight = { moveCursor(1) }
                        )
                    }
                }
                StudioTab.OUTPUT -> {
                    ConsolePanel(
                        feed = feed,
                        status = status,
                        elapsed = elapsed,
                        awaiting = awaiting,
                        height = consoleH,
                        onDrag = { dy -> consoleH = (consoleH - with(density) { dy.toDp() }).coerceIn(150.dp, 560.dp) },
                        onClose = { workspaceTab = StudioTab.EDITOR },
                        onClear = { feed.clear() },
                        onSend = { s -> awaiting = false; Py.input(s) },
                        onImage = { viewer = it },
                        expanded = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                StudioTab.TERMINAL -> {
                    TerminalPanel(
                        initialDirectory = cwd,
                        onPipInstall = { packageName, onLog, onDone -> Py.install(packageName, onLog) { _, message -> onDone(message) } },
                        onPipUninstall = { packageName, onDone -> Py.uninstallForTerminal(packageName, onDone) },
                        onPipList = { onResult -> Py.listInstalled { packages -> onResult(if (packages.isEmpty()) "No user-installed packages found." else packages.joinToString("\n") { "${it.first}  ${it.second}" }) } },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Persistent workspace navigation. Output no longer steals space below the editor.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(16.dp))
                    .padding(5.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                listOf(StudioTab.EDITOR to "Code", StudioTab.OUTPUT to "Output", StudioTab.TERMINAL to "Terminal").forEach { (tab, label) ->
                    val selected = workspaceTab == tab
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                            .background(if (selected) Card2 else Color.Transparent)
                            .clickable { workspaceTab = tab }
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = if (selected) Cyan else Dim, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }

        }

        // ================= dialogs =================
        if (!granted && permAsk) {
            PermissionDialog(
                onOpen = { permAsk = false; openAllFilesSettings(ctx) },
                onLater = { permAsk = false }
            )
        }
        if (showOpen) {
            BrowserDialog(
                mode = BrowseMode.OPEN,
                start = curFile?.parentFile ?: workspace,
                granted = granted,
                onGrant = { openAllFilesSettings(ctx) },
                onDismiss = { showOpen = false },
                onFile = { f ->
                    showOpen = false
                    guard { openFile(f) }
                },
                onFolder = { }
            )
        }
        if (showInsert) {
            BrowserDialog(
                mode = BrowseMode.INSERT,
                start = File(cwd),
                granted = granted,
                onGrant = { openAllFilesSettings(ctx) },
                onDismiss = { showInsert = false },
                onFile = { f ->
                    showInsert = false
                    val p = if (f.parentFile?.absolutePath == cwd) f.name else f.absolutePath
                    edit(insertText(code, "\"" + p + "\""))
                },
                onFolder = { }
            )
        }
        if (showFolder) {
            BrowserDialog(
                mode = BrowseMode.FOLDER,
                start = File(cwd),
                granted = granted,
                onGrant = { openAllFilesSettings(ctx) },
                onDismiss = { showFolder = false },
                onFile = { },
                onFolder = { d ->
                    showFolder = false
                    cwdOverride = d.absolutePath
                    prefs.edit().putString("cwd", d.absolutePath).apply()
                }
            )
        }
        if (showLibs) LibrariesDialog { showLibs = false }
        saveAs?.let { req ->
            NameDialog(
                title = "Save as",
                initial = curFile?.name ?: "untitled.py",
                onDismiss = { saveAs = null },
                onOk = { raw -> trySaveAs(raw, req) }
            )
        }
        pending?.let { act ->
            UnsavedDialog(
                name = curFile?.name ?: "untitled.py",
                onSave = {
                    pending = null
                    save(act)
                },
                onDiscard = {
                    pending = null
                    act()
                },
                onCancel = { pending = null }
            )
        }
        viewer?.let { img ->
            ImageViewer(
                img = img,
                onSave = {
                    val ok = saveToGallery(ctx, File(img.path))
                    toast(if (ok) "Saved to Pictures/PyStudio" else "Could not save the image")
                },
                onDismiss = { viewer = null }
            )
        }
    }
}
