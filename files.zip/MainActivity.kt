package com.hoosha.pydroid

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONTokener

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var txtOutput: TextView
    private lateinit var scrollOutput: ScrollView
    private lateinit var panelImage: ScrollView
    private lateinit var imgPreview: ImageView
    private lateinit var panelPackages: LinearLayout
    private lateinit var editPackage: EditText
    private lateinit var txtPipStatus: TextView
    private lateinit var tabOutput: TextView
    private lateinit var tabImage: TextView
    private lateinit var tabPackages: TextView

    private var bootstrap: PyObject? = null
    private var lastImageUri: String? = null

    companion object {
        private val DEFAULT_CODE = """
            # 🎨 نمونهٔ پردازش تصویر با OpenCV
            # اول دکمهٔ 🖼 را بزن و یک عکس از گالری انتخاب کن

            img = imread()
            print("ابعاد تصویر:", img.shape)

            gray  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            blur  = cv2.GaussianBlur(gray, (5, 5), 0)
            edges = cv2.Canny(blur, 80, 180)

            show_image(edges, "لبه‌یابی Canny ✓")
        """.trimIndent()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()

        setupEditor()
        setupButtons()
        setupPython()
        ensureStoragePermission()
        showTab("output")
    }

    private fun bindViews() {
        webView        = findViewById(R.id.editorWebView)
        txtOutput      = findViewById(R.id.txtOutput)
        scrollOutput   = findViewById(R.id.scrollOutput)
        panelImage     = findViewById(R.id.panelImage)
        imgPreview     = findViewById(R.id.imgPreview)
        panelPackages  = findViewById(R.id.panelPackages)
        editPackage    = findViewById(R.id.editPackage)
        txtPipStatus   = findViewById(R.id.txtPipStatus)
        tabOutput      = findViewById(R.id.tabOutput)
        tabImage       = findViewById(R.id.tabImage)
        tabPackages    = findViewById(R.id.tabPackages)
    }

    private fun setupEditor() {
        webView.settings.javaScriptEnabled = true
        webView.setBackgroundColor(0xFF0D1117.toInt())
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (lastImageUri == null) setEditorCode(DEFAULT_CODE)
            }
        }
        webView.loadUrl("file:///android_asset/editor/index.html")
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnRun).setOnClickListener { runCode() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveCode() }
        findViewById<Button>(R.id.btnOpen).setOnClickListener { openCode() }
        findViewById<Button>(R.id.btnPickImage).setOnClickListener { pickImage() }
        findViewById<Button>(R.id.btnInstall).setOnClickListener { installPackage() }

        tabOutput.setOnClickListener { showTab("output") }
        tabImage.setOnClickListener { showTab("image") }
        tabPackages.setOnClickListener { showTab("packages") }
    }

    private fun setupPython() {
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        bootstrap = Python.getInstance().getModule("bootstrap")
        bootstrap!!.callAttr("init")
        txtPipStatus.text = "پیش‌نصب‌شده: numpy · opencv-python · Pillow\nنام پکیج را بنویس و «نصب» را بزن…"
    }

    private fun getCode(callback: (String) -> Unit) {
        webView.evaluateJavascript("getCode()") { raw ->
            val code = try { JSONTokener(raw).nextValue() as? String } catch (e: Exception) { null }
            callback(code ?: "")
        }
    }

    private fun setEditorCode(code: String) {
        val js = "setCode(" + org.json.JSONObject.quote(code) + ")"
        webView.evaluateJavascript(js, null)
    }

    private fun runCode() {
        showTab("output")
        getCode { code ->
            if (code.isBlank()) {
                txtOutput.text = "ادیتور خالی است!"
                return@getCode
            }
            txtOutput.text = "⏳ در حال اجرا…\n\n"
            Thread {
                try {
                    bootstrap!!.callAttr("run_code", code, PyObject.fromJava(PyBridge()))
                } catch (e: Exception) {
                    runOnUiThread { appendOut("\n✗ خطای اجرا: ${e.message}") }
                }
            }.start()
        }
    }

    private fun appendOut(text: String) {
        txtOutput.append(text)
        scrollOutput.post { scrollOutput.fullScroll(View.FOCUS_DOWN) }
    }

    private val saveLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data ?: return@registerForActivityResult
        getCode { code ->
            contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray(Charsets.UTF_8)) }
            txtOutput.text = "✓ فایل ذخیره شد:\n$uri"
        }
    }

    private val openLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data ?: return@registerForActivityResult
        val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
        setEditorCode(text)
        txtOutput.text = "✓ فایل باز شد (${text.length} کاراکتر)"
    }

    private val imageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data ?: return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) { }
        lastImageUri = uri.toString()
        bootstrap!!.callAttr("set_image_uri", lastImageUri)
        showTab("output")
        txtOutput.text = "✓ تصویر انتخاب شد (خواندن مستقیم از حافظهٔ گوشی، بدون کپی)\n\nحالا در کد از imread() استفاده کن."
    }

    private fun saveCode() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/x-python"
            putExtra(Intent.EXTRA_TITLE, "main.py")
        }
        saveLauncher.launch(intent)
    }

    private fun openCode() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        openLauncher.launch(intent)
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "image/png", "image/webp", "image/bmp"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        imageLauncher.launch(intent)
    }

    private fun installPackage() {
        val name = editPackage.text.toString().trim()
        if (name.isEmpty()) return
        showTab("output")
        txtOutput.text = "⏳ در حال نصب «$name»…\n\n"
        Thread {
            val ok = try {
                bootstrap!!.callAttr("install_package", name, PyObject.fromJava(PyBridge()))
                    .toJava(Boolean::class.java)
            } catch (e: Exception) {
                runOnUiThread { appendOut("\n✗ ${e.message}") }
                false
            }
            runOnUiThread {
                txtPipStatus.text = if (ok)
                    "✓ «$name» نصب شد. (پکیج‌های بومی: یک‌بار اپ را ببند و باز کن)"
                else "✗ نصب «$name» ناموفق بود — جزئیات در پنل خروجی."
            }
        }.start()
    }

    private fun ensureStoragePermission() {
        val perm = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(perm), 10)
        }
    }

    private fun showTab(which: String) {
        scrollOutput.visibility  = if (which == "output")   View.VISIBLE else View.GONE
        panelImage.visibility    = if (which == "image")    View.VISIBLE else View.GONE
        panelPackages.visibility = if (which == "packages") View.VISIBLE else View.GONE

        val active = ContextCompat.getColor(this, R.color.accent)
        val muted  = ContextCompat.getColor(this, R.color.textMuted)
        val tabs = mapOf("output" to tabOutput, "image" to tabImage, "packages" to tabPackages)
        for ((key, t) in tabs) {
            val on = key == which
            t.setTextColor(if (on) active else muted)
            t.setBackgroundResource(if (on) R.drawable.bg_tab_active else 0)
        }
    }

    inner class PyBridge {
        fun onOutput(text: String) = runOnUiThread { appendOut(text) }

        fun onImage(png: ByteArray) {
            val bmp = BitmapFactory.decodeByteArray(png, 0, png.size)
            runOnUiThread {
                imgPreview.setImageBitmap(bmp)
                showTab("image")
            }
        }

        fun readUriBytes(uriStr: String): ByteArray? = try {
            contentResolver.openInputStream(Uri.parse(uriStr))?.use { it.readBytes() }
        } catch (e: Exception) { null }

        fun writeUriBytes(uriStr: String, data: ByteArray): Boolean = try {
            contentResolver.openOutputStream(Uri.parse(uriStr))?.use { it.write(data) }
            true
        } catch (e: Exception) { false }
    }
}