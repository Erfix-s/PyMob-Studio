package com.pystudio.app

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File

@Composable
fun DialogBtn(label: String, primary: Boolean, onClick: () -> Unit) {
    Text(
        label, color = if (primary) Cyan else Dim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    )
}

@Composable
fun FileRow(icon: String, thumb: File?, title: String, sub: String, dim: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).alpha(if (dim) 0.4f else 1f)
            .clickable(enabled = !dim, onClick = onClick).padding(horizontal = 6.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Card2),
            contentAlignment = Alignment.Center
        ) {
            if (thumb != null) AsyncImg(thumb.absolutePath, 128, Modifier.fillMaxSize(), ContentScale.Crop, thumb.lastModified())
            else Text(icon, fontSize = 22.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Dim, fontSize = 12.sp, maxLines = 1)
        }
    }
}

enum class BrowseMode { OPEN, INSERT, FOLDER }

@Composable
fun BrowserDialog(
    mode: BrowseMode,
    start: File,
    granted: Boolean,
    onGrant: () -> Unit,
    onDismiss: () -> Unit,
    onFile: (File) -> Unit,
    onFolder: (File) -> Unit
) {
    val root = remember { Environment.getExternalStorageDirectory() }
    var dir by remember { mutableStateOf(if (start.isDirectory) start else root) }
    val entries = remember(dir, granted) { listDir(dir) }
    val shape = RoundedCornerShape(24.dp)
    val title = when (mode) {
        BrowseMode.OPEN -> "Open file"
        BrowseMode.INSERT -> "Insert file path"
        BrowseMode.FOLDER -> "Choose working folder"
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.8f).clip(shape)
                .background(Card).border(1.dp, Line, shape)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(prettyPath(dir), color = Dim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(
                    "\u2715", color = Dim, fontSize = 16.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onDismiss)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
            if (mode == BrowseMode.FOLDER) {
                Box(
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(50))
                        .background(Grad).clickable { onFolder(dir) }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) { Text("Use this folder", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
            }
            if (!granted && dir.absolutePath == root.absolutePath) {
                Column(Modifier.weight(1f).padding(20.dp)) {
                    Text(
                        "Allow \"All files access\" to browse your phone.",
                        color = Dim, fontSize = 14.sp, lineHeight = 20.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(Grad).clickable(onClick = onGrant)
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                    ) { Text("Open settings", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    if (dir.absolutePath != root.absolutePath) {
                        item { FileRow("\u2191", null, "Up", "Parent folder") { dir = dir.parentFile ?: root } }
                    }
                    items(entries, key = { it.absolutePath }) { f ->
                        when {
                            f.isDirectory -> FileRow("\uD83D\uDCC1", null, f.name, "Folder") { dir = f }
                            isImage(f) -> FileRow(
                                "\uD83D\uDDBC", f, f.name, fmtSize(f.length()),
                                dim = mode != BrowseMode.INSERT
                            ) { onFile(f) }
                            else -> FileRow(
                                "\uD83D\uDCC4", null, f.name, fmtSize(f.length()),
                                dim = mode == BrowseMode.FOLDER || (mode == BrowseMode.OPEN && !isTextFile(f))
                            ) { onFile(f) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> String?) {
    var text by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, initial.removeSuffix(".py").length))) }
    var err by remember { mutableStateOf<String?>(null) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        titleContentColor = Ink,
        textContentColor = Dim,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card2)
                        .border(1.dp, Line, RoundedCornerShape(12.dp)).padding(14.dp)
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = {
                            text = it
                            err = null
                        },
                        singleLine = true,
                        textStyle = TextStyle(color = Ink, fontSize = 16.sp),
                        cursorBrush = SolidColor(Cyan),
                        modifier = Modifier.fillMaxWidth().focusRequester(fr)
                    )
                }
                val e = err
                if (e != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(e, color = Rose, fontSize = 13.sp)
                }
            }
        },
        confirmButton = { DialogBtn("Save", true) { err = onOk(text.text) } },
        dismissButton = { DialogBtn("Cancel", false, onDismiss) }
    )
}

@Composable
fun UnsavedDialog(name: String, onSave: () -> Unit, onDiscard: () -> Unit, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Card,
        titleContentColor = Ink,
        textContentColor = Dim,
        title = { Text("Unsaved changes", fontWeight = FontWeight.Bold) },
        text = { Text("Save \"$name\" before continuing?") },
        confirmButton = { DialogBtn("Save", true, onSave) },
        dismissButton = {
            Row {
                DialogBtn("Discard", false, onDiscard)
                DialogBtn("Cancel", false, onCancel)
            }
        }
    )
}

@Composable
fun PermissionDialog(onOpen: () -> Unit, onLater: () -> Unit) {
    AlertDialog(
        onDismissRequest = onLater,
        containerColor = Card,
        titleContentColor = Ink,
        textContentColor = Dim,
        title = { Text("Allow file access", fontWeight = FontWeight.Bold) },
        text = {
            Text(
                "PyStudio saves your scripts in a PyStudio folder and lets your code read and write " +
                    "your photos directly. Turn on \"All files access\" on the next screen."
            )
        },
        confirmButton = { DialogBtn("Open settings", true, onOpen) },
        dismissButton = { DialogBtn("Not now", false, onLater) }
    )
}

@Composable
fun LibrariesDialog(onDismiss: () -> Unit) {
    var installed by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    fun refresh() {
        Py.listInstalled { installed = it }
    }
    LaunchedEffect(Unit) { refresh() }
    val shape = RoundedCornerShape(24.dp)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.94f).heightIn(max = 560.dp).clip(shape)
                .background(Card).border(1.dp, Line, shape)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Libraries", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(
                    "\u2715", color = Dim, fontSize = 16.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onDismiss)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
            Column(
                Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    "Just write  import name  in your code. If a pure-Python library is missing, " +
                        "PyStudio downloads it automatically (internet is needed the first time).",
                    color = Dim, fontSize = 13.sp, lineHeight = 19.sp
                )
                Spacer(Modifier.height(16.dp))
                Text("Built in", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text("NumPy  \u00B7  Pillow  \u00B7  OpenCV", color = Cyan, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Text("Downloaded", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                if (installed.isEmpty()) {
                    Text("Nothing yet", color = Dim, fontSize = 13.sp)
                } else {
                    installed.forEach { (n, v) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("$n  $v", color = Ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(
                                "Remove", color = Rose, fontSize = 13.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50))
                                    .clickable { Py.uninstall(n) { refresh() } }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun ImageViewer(img: Img, onSave: () -> Unit, onDismiss: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xF2000000))) {
            AsyncImg(
                img.path, 2400,
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 8f)
                            offset = if (scale <= 1f) Offset.Zero else offset + pan
                        }
                    }
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    },
                ContentScale.Fit, img.ver
            )
            Text(
                "\u2715", color = Color.White, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(12.dp)
                    .clip(RoundedCornerShape(50)).background(Color(0x66000000))
                    .clickable(onClick = onDismiss).padding(horizontal = 16.dp, vertical = 10.dp)
            )
            Text(
                "Save to Photos", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.align(Alignment.BottomCenter).systemBarsPadding().padding(20.dp)
                    .clip(RoundedCornerShape(50)).background(Grad)
                    .clickable(onClick = onSave).padding(horizontal = 24.dp, vertical = 12.dp)
            )
        }
    }
}
