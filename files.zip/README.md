# PyStudio 2.1

PyStudio is an Android Python IDE powered by Chaquopy.

## Workspace
- **Code**: edit and run Python scripts with the built-in editor.
- **Output**: view stdout, stderr, input prompts, and generated images on a dedicated screen.
- **Terminal**: run commands using Android's `/system/bin/sh` and manage supported Python packages with `pip install`, `pip uninstall`, and `pip list`.

## Terminal notes
This is an Android shell, not a full Linux distribution. Android does not provide `apt`, `sudo`, `systemctl`, or a conventional desktop Linux environment. Shell commands run with the app's Android permissions. The in-app package installer supports compatible pure-Python wheels; packages requiring native compiled extensions must be bundled into the APK. NumPy, Pillow, and OpenCV are bundled with this build.

## Build
The GitHub Actions workflow builds the debug APK and publishes it as a workflow artifact and GitHub Release asset.
